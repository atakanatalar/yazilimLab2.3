﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Neo4jApi.Models;
using Neo4jClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Neo4jApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArastirmaciController : ControllerBase
    {
        private readonly IGraphClient _client;

        public ArastirmaciController(IGraphClient client)
        {
            _client = client;
        }

        [HttpGet("getall")]
        public async Task<IActionResult> Get()
        {
            List<GetModel> models = new List<GetModel>();

            var arastirmacilar = await _client.Cypher.Match("(a:Arastirmaci)")
                .Return(a => a.As<Arastirmaci>()).ResultsAsync;

            var aList = arastirmacilar.ToList();

            for (int i = 0; i < aList.Count; i++)
            {
                var yayinlar = await _client.Cypher.Match($"(a:Arastirmaci{{aid:'{aList[i].aid}'}})-[:Yayin_Yazari]->(y:Yayinlar)")
                    .Return(y => y.As<Yayinlar>()).ResultsAsync;

                var yList = yayinlar.ToList();  

                for (int j = 0; j < yList.Count; j++)
                {
                    var tur = await _client.Cypher.Match($"(y:Yayinlar{{yid:'{yList[j].yid}'}})-[:Yayinlanir]->(t:Tur)")
                        .Return(t => t.As<Tur>()).ResultsAsync;
                    yList[j].Tur = tur.ToList()[0];
                }

                models.Add(new GetModel
                {
                    Arastirmaci = new Arastirmaci { aid = aList[i].aid, isim = aList[i].isim, soyisim = aList[i].soyisim },
                    Yayinlar = yList,
                });

            }

            return Ok(models);
        }

        [HttpGet("getbyid")]
        public async Task<IActionResult> GetById(string uuid)
        {
            GetModel model = new GetModel();

            var arastirmacilar = await _client.Cypher.Match($"(a:Arastirmaci{{aid:'{uuid}'}})")
                .Return(a => a.As<Arastirmaci>()).ResultsAsync;

            var aList = arastirmacilar.ToList();

            for (int i = 0; i < aList.Count; i++)
            {
                var yayinlar = await _client.Cypher.Match($"(a:Arastirmaci{{aid:'{aList[i].aid}'}})-[:Yayin_Yazari]->(y:Yayinlar)")
                    .Return(y => y.As<Yayinlar>()).ResultsAsync;

                var yList = yayinlar.ToList();

                for (int j = 0; j < yList.Count; j++)
                {
                    var tur = await _client.Cypher.Match($"(y:Yayinlar{{yid:'{yList[j].yid}'}})-[:Yayinlanir]->(t:Tur)")
                        .Return(t => t.As<Tur>()).ResultsAsync;
                    yList[j].Tur = tur.ToList()[0];
                }

                model.Arastirmaci = new Arastirmaci { aid = aList[i].aid, isim = aList[i].isim, soyisim = aList[i].soyisim };
                model.Yayinlar = yList;

            }

            return Ok(model);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody]PostModel model)
        {
            string arastirmaciId,yayinId,turId;

            var arastirmaci = await _client.Cypher.Match("(a:Arastirmaci)")
                .Where((Arastirmaci a) => a.isim == model.isim && a.soyisim == model.soyisim)
                .Return(a => a.As<Arastirmaci>()).ResultsAsync;
            
            if(arastirmaci.Count() == 0)
            {
                arastirmaciId = Guid.NewGuid().ToString();

                await _client.Cypher.
                    Create($"(a: Arastirmaci{{aid : '{arastirmaciId}', isim: '{model.isim}',soyisim: '{model.soyisim}'}})")
                    .ExecuteWithoutResultsAsync();
            }
            else
            {
                arastirmaciId = arastirmaci.ToList()[0].aid;
            }

            var yayin = await _client.Cypher.Match("(y:Yayinlar)")
                .Where((Yayinlar y) => y.yayinYeri == model.yayinYeri && y.yil == model.yil
                && y.baslik == model.baslik)
                .Return(y => y.As<Yayinlar>()).ResultsAsync;

            if (yayin.Count() == 0)
            {
                yayinId = Guid.NewGuid().ToString();    

                await _client.Cypher.
                    Create($"(y: Yayinlar{{yid : '{yayinId}', baslik: '{model.baslik}',yayinYeri : '{model.yayinYeri}',yil : '{model.yil}'}})")
                    .ExecuteWithoutResultsAsync();
            }
            else
            {
                yayinId = yayin.ToList()[0].yid;
            }

            var tur = await _client.Cypher.Match("(t:Tur)")
                .Where((Tur t) => t.turAdi == model.tur)
                .Return(t => t.As<Tur>()).ResultsAsync;

            if(tur.Count() == 0)
            {
                turId = Guid.NewGuid().ToString();
                await _client.Cypher.
                    Create($"(t: Tur{{tid : '{turId}', turAdi : '{model.tur}'}})")
                    .ExecuteWithoutResultsAsync();
            }
            else
            {
                turId = tur.ToList()[0].tid;
            }


            await _client.Cypher.Match("(a:Arastirmaci), (y:Yayinlar)")
                .Where((Arastirmaci a, Yayinlar y) => a.aid == arastirmaciId && y.yid == yayinId)
                .Create("(a)-[r:Yayin_Yazari] -> (y)")
                .ExecuteWithoutResultsAsync();

            var matchTur = await _client.Cypher
                        .Match($"(y:Yayinlar{{yid:'{yayinId}'}})-[:Yayinlanir]->(t:Tur{{tid:'{turId}'}})")
                        .Return(t => t.As<Tur>()).ResultsAsync;

            if(matchTur.Count() == 0)
            {
                await _client.Cypher.Match("(y:Yayinlar), (t:Tur)")
                .Where((Yayinlar y, Tur t) => y.yid == yayinId && t.tid == turId)
                .Create("(y)-[:Yayinlanir] -> (t)")
                .ExecuteWithoutResultsAsync();
            }

            var ortakYayin = await _client.Cypher.Match($"(a:Arastirmaci)-[:Yayin_Yazari]->(y:Yayinlar{{yid:'{yayinId}'}})")
                .Return(a => a.As<Arastirmaci>()).ResultsAsync;

            var list = ortakYayin.ToList();

            for (int i = 0; i < list.Count; i++)
            {
                for (int j = 0; j < list.Count; j++)
                {
                    var matchArastirmaci = await _client.Cypher
                        .Match($"(a1:Arastirmaci{{aid:'{list[i].aid}'}})-[:Ortak_Calisir]->(a2:Arastirmaci{{aid:'{list[j].aid}'}})")
                        .Return(a1 => a1.As<Arastirmaci>()).ResultsAsync;

                    if (i != j && matchArastirmaci.Count() == 0)
                    {
                        await _client.Cypher
                        .Match($"(a1:Arastirmaci{{aid:'{list[i].aid}'}}), (a2:Arastirmaci{{aid:'{list[j].aid}'}})")
                        .Create("(a1)-[r:Ortak_Calisir] -> (a2)")
                        .ExecuteWithoutResultsAsync();
                    }
                }
            }

            return Ok();
        }
    }
}
