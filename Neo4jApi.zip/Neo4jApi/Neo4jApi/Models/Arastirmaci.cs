﻿using System;

namespace Neo4jApi.Models
{
    public class Arastirmaci
    {
        public string aid { get; set; }
        public string isim { get; set; }
        public string soyisim { get; set; }
    }
}
