﻿using System.Collections.Generic;

namespace Neo4jApi.Models
{
    public class GetModel
    {
        public Arastirmaci Arastirmaci { get; set; }
        public List<Yayinlar> Yayinlar { get; set; }

    }
}
