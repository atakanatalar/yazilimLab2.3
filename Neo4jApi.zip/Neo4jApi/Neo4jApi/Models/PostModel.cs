﻿namespace Neo4jApi.Models
{
    public class PostModel
    {
        public string isim { get; set; }
        public string soyisim { get; set; }
        public string baslik { get; set; }
        public string tur { get; set; }
        public string yayinYeri { get; set; }
        public string yil { get; set; }
    }
}
