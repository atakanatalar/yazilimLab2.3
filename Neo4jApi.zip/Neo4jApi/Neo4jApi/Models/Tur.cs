﻿namespace Neo4jApi.Models
{
    public class Tur
    {
        public string tid { get; set; }
        public string turAdi { get; set; }
    }
}
