﻿using System;

namespace Neo4jApi.Models
{
    public class Yayinlar
    {
        public string yid { get;  set; }
        public string baslik { get; set; }
        public string yayinYeri { get; set; }
        public string yil { get; set; }
        public Tur Tur { get; set; }
    }
}
